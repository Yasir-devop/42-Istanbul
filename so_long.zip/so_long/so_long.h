/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ykurt <42istanbul.com.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/30 12:33:10 by ykurt             #+#    #+#             */
/*   Updated: 2022/06/02 16:30:02 by ykurt            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H

# include "./librarys/minilibx_macos/mlx.h"
# include "./librarys/ft_printf/ft_printf.h"
# include "./librarys/libft/libft.h"
# include <unistd.h>
# include <fcntl.h>

typedef struct s_long
{
	void	*mlx;
	void	*win;
	void	*img_p;
	void	*img_w;
	void	*img_e;
	void	*img_e2;
	void	*img_c;
	void	*img_back;
	char	*map;
	int		height;
	int		width;
	int		c_count;
	int		p_count;
	int		e_count;
	int		map_x;
	int		map_y;
	int		img_x;
	int		img_y;
	int		collected_c;
	int		step_count;
}t_long;

int		so_long(t_long *s_long, char *map_name);
int		control_value_count(t_long *s_long, char *map);
void	start_mlx(t_long *s_long, char *map);
int		move(int key_code, t_long *s_long);
int		ft_exit(void);
void	print_map(t_long *s_long);
int		error(int error_key_code);

#endif
