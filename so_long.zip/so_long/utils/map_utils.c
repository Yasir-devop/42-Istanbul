/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_utils.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ykurt <42istanbul.com.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/30 12:34:49 by ykurt             #+#    #+#             */
/*   Updated: 2022/06/02 13:19:52 by ykurt            ###   ########.tr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

int	control_value_2(t_long *s_long, char *map)
{
	int	i;

	i = 0;
	s_long->c_count = 0;
	s_long->p_count = 0;
	s_long->e_count = 0;
	while (map[i])
	{
		if (map[i] == 'P')
		{
			s_long->p_count++;
			if (s_long->p_count > 1)
				return (error(8));
		}
		else if (map[i] == 'C')
			s_long->c_count++;
		else if (map[i] == 'E')
			s_long->e_count++;
		i++;
	}
	control_value_count(s_long, map);
	return (1);
}

int	control_value(t_long *s_long, char *map)
{
	int		i;

	i = 0;
	while (map[i])
	{
		if (map[i] != '0' && map[i] != '1' && map[i] != 'P' && \
				map [i] != 'E' && map[i] != 'C' && map[i] != '\n')
			return (error(9));
		i++;
	}
	control_value_2(s_long, map);
	return (1);
}

char	*read_map(int fd)
{
	char	*input;
	char	*result;
	char	*tmp;

	input = (char *)malloc(2 * sizeof(char));
	if (!input)
	{
		error(7);
		return (NULL);
	}
	input[1] = '\0';
	result = ft_strdup("");
	while (read(fd, input, 1))
	{
		tmp = ft_strjoin(result, input);
		free(result);
		result = tmp;
	}
	free(input);
	return (result);
}

int	check_ber(char *map_name)
{
	int		i;

	i = ft_strlen(map_name) - 1;
	if (map_name[i] != 'r')
		return (0);
	i -= 1;
	if (map_name[i] != 'e')
		return (0);
	i -= 1;
	if (map_name[i] != 'b')
		return (0);
	i -= 1;
	if (map_name[i] != '.')
		return (0);
	return (1);
}

int	so_long(t_long *s_long, char *map_name)
{
	int		fd;
	char	*map;

	if (check_ber(map_name) == 0)
		return (error(3));
	fd = open(map_name, O_RDONLY);
	if (fd < 0)
		return (error(2));
	map = read_map(fd);
	if (control_value(s_long, map) == 0)
		return (0);
	return (1);
}
