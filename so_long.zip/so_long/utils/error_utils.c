/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error_utils.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ykurt <42istanbul.com.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/06 10:57:56 by ykurt             #+#    #+#             */
/*   Updated: 2022/06/06 11:07:43 by ykurt            ###   ########.tr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

int	error(int error_key_code)
{
	if (error_key_code == 1)
		ft_printf("Error\n\nMissing argument!!");
	else if (error_key_code == 2)
		ft_printf("Error\n\nThe file could not be read!!");
	else if (error_key_code == 3)
		ft_printf("Error\n\nWrong map extension!!");
	else if (error_key_code == 4)
		ft_printf("Error\n\nThere is a problem with the walls of the map!!\n");
	else if (error_key_code == 5)
		ft_printf("Error\n\nThe lengths of the rows of the map are not equal!!");
	else if (error_key_code == 6)
		ft_printf("Error\n\nThe array could not be created!!\n");
	else if (error_key_code == 7)
		ft_printf("Error\n\n'P', 'E', 'C' must be at least 1 piece!!");
	else if (error_key_code == 8)
		ft_printf("Error\n\nThere can't be more than one 'P' on the map!!");
	else if (error_key_code == 9)
		ft_printf("Error\n\nThere can be no invalid characters on the map!!");
	else if (error_key_code == 10)
		ft_printf("Error\n\nWrong picture !!");
	return (0);
}

int	ft_exit(void)
{
	exit(1);
	return (0);
}
