/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mlx_utils.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ykurt <42istanbul.com.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/30 12:35:24 by ykurt             #+#    #+#             */
/*   Updated: 2022/06/06 11:59:33 by ykurt            ###   ########.tr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

void	img_state_check(t_long *s_long)
{
	if (!(s_long->img_p) || !(s_long->img_c) || !(s_long->img_w) || \
			!(s_long->img_e) || !(s_long->img_e2) || !(s_long->img_back))
	{
		error(10);
		ft_exit();
	}
}

void	print_image(t_long *s_long, char c)
{
	img_state_check(s_long);
	if (c == '1')
		mlx_put_image_to_window(s_long->mlx, s_long->win, \
				s_long->img_w, s_long->img_x, s_long->img_y);
	else if (c == '0')
		mlx_put_image_to_window(s_long->mlx, s_long->win, \
				s_long->img_back, s_long->img_x, s_long->img_y);
	else if (c == 'P')
		mlx_put_image_to_window(s_long->mlx, s_long->win, \
				s_long->img_p, s_long->img_x, s_long->img_y);
	else if (c == 'C')
		mlx_put_image_to_window(s_long->mlx, s_long->win, \
				s_long->img_c, s_long->img_x, s_long->img_y);
	else if (c == 'E')
	{
		if (s_long->collected_c == s_long->c_count)
			mlx_put_image_to_window(s_long->mlx, s_long->win, \
					s_long->img_e2, s_long->img_x, s_long->img_y);
		else
			mlx_put_image_to_window(s_long->mlx, s_long->win, \
					s_long->img_e, s_long->img_x, s_long->img_y);
	}
}

void	print_map(t_long *s_long)
{
	int		i;
	char	*map;

	i = 0;
	s_long->img_x = -64;
	s_long->img_y = 0;
	map = s_long->map;
	while (map[i])
	{
		if (map[i] == '\n')
		{
			s_long->img_x = -64;
			s_long->img_y += 64;
		}
		else
			s_long->img_x += 64;
		print_image(s_long, map[i]);
		i++;
	}
}

void	img_declaration(t_long *s_long)
{	
	s_long->img_p = mlx_xpm_file_to_image(s_long->mlx, \
			"./img/player.xpm", &s_long->width, &s_long->height);
	s_long->img_c = mlx_xpm_file_to_image(s_long->mlx, \
			"./img/shield.xpm", &s_long->width, &s_long->height);
	s_long->img_w = mlx_xpm_file_to_image(s_long->mlx, \
			"./img/wall4.xpm", &s_long->width, &s_long->height);
	s_long->img_e = mlx_xpm_file_to_image(s_long->mlx, \
			"./img/exit_close.xpm", &s_long->width, &s_long->height);
	s_long->img_e2 = mlx_xpm_file_to_image(s_long->mlx, \
			"./img/exit_open.xpm", &s_long->width, &s_long->height);
	s_long->img_back = mlx_xpm_file_to_image(s_long->mlx, \
			"./img/back.xpm", &s_long->width, &s_long->height);
}

void	start_mlx(t_long *s_long, char *map)
{
	s_long->map = map;
	s_long->collected_c = 0;
	s_long->step_count = 0;
	s_long->mlx = mlx_init();
	s_long->win = mlx_new_window(s_long->mlx, s_long->map_x * 64, \
			s_long->map_y * 64, "So Long");
	img_declaration(s_long);
	print_map(s_long);
	mlx_hook(s_long->win, 2, 1L << 0, move, s_long);
	mlx_hook(s_long->win, 17, 0, ft_exit, s_long);
	mlx_loop(s_long->mlx);
}
