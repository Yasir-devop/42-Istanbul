/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_utils2.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ykurt <42istanbul.com.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/30 12:35:02 by ykurt             #+#    #+#             */
/*   Updated: 2022/06/02 13:39:24 by ykurt            ###   ########.tr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

int	line_lenght_check(t_long *s_long, char *map)
{
	int		i;
	char	**array;

	i = 0;
	array = ft_split(map, '\n');
	while (array[i])
	{
		if (ft_strlen(array[1]) != ft_strlen(array[i]))
			return (error(5));
		i++;
	}
	start_mlx(s_long, map);
	return (1);
}

int	shape_check(t_long *s_long, char *map)
{
	int		i;

	i = 0;
	s_long->map_x = 0;
	s_long->map_y = 0;
	while (map[i] != '\n')
		i++;
	s_long->map_x = i;
	while (map[i])
	{
		if (map[i] == '\n')
			s_long->map_y++;
		i++;
	}
	s_long->map_y++;
	line_lenght_check(s_long, map);
	return (1);
}

int	wall_check(t_long *s_long, char *map)
{
	int		i;

	i = 0;
	while (map[i] != '\n')
	{
		if (map[i] != '1')
			return (error(4));
		i++;
	}
	while (map[i])
	{
		if (map[i] == '\n')
			if (map[i - 1] != '1' || map[i + 1] != '1')
				return (error(4));
		i++;
	}
	i = ft_strlen(map) - 1;
	while (map[i] != '\n')
	{
		if (map[i] != '1')
			return (error(4));
		i--;
	}
	shape_check(s_long, map);
	return (1);
}

int	control_value_count(t_long *s_long, char *map)
{
	if (s_long->p_count < 1 || s_long->c_count < 1 || \
			s_long->e_count < 1)
		return (error(7));
	wall_check(s_long, map);
	return (1);
}
