/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   move_utils.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ykurt <42istanbul.com.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/30 12:35:39 by ykurt             #+#    #+#             */
/*   Updated: 2022/06/06 13:58:44 by ykurt            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

void	move_mix(t_long *s_long, int number)
{
	int		i;
	char	*map;

	i = 0;
	map = s_long->map;
	while (map[i] != 'P')
		i++;
	if (map[i + number] == 'E')
	{
		if (s_long->collected_c == s_long->c_count)
			ft_exit();
	}
	else if (map[i + number] != '1')
	{
		if (map[i + number] == 'C')
			s_long->collected_c++;
		map[i] = '0';
		map[i + number] = 'P';
		s_long->step_count++;
		s_long->map = map;
		ft_printf("\033[0;31mShield Count: %d/%d\t\033[0;34mMove : %d\n", \
				s_long->collected_c, s_long->c_count, s_long->step_count);
	}
	mlx_clear_window(s_long->mlx, s_long->win);
	print_map(s_long);
}

int	move(int key_code, t_long *s_long)
{
	if (key_code == 2)
		move_mix(s_long, 1);
	else if (key_code == 0)
		move_mix(s_long, -1);
	else if (key_code == 13)
		move_mix(s_long, -s_long->map_x -1);
	else if (key_code == 1)
		move_mix(s_long, +s_long->map_x +1);
	else if (key_code == 53)
		ft_exit();
	return (0);
}
