/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: omorkoc <42istanbul.com.tr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/11 11:27:35 by omorkoc           #+#    #+#             */
/*   Updated: 2022/04/12 17:14:37 by omorkoc          ###   ########.tr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	check(char c, va_list arg_list)
{	
	if (c == 'd' || c == 'i')
		return (ft_putnbr(va_arg(arg_list, int)));
	else if (c == 'c')
		return (ft_putchar(va_arg(arg_list, int)));
	else if (c == 's')
		return (ft_putstr(va_arg(arg_list, char *)));
	else if (c == 'p')
	{
		return (ft_putstr("0x") \
			+ ft_hex(va_arg(arg_list, t_l), "0123456789abcdef"));
	}
	else if (c == 'u')
		return (ft_putnbr_u(va_arg(arg_list, t_u)));
	else if (c == 'x')
		return (ft_hex(va_arg(arg_list, t_u), "0123456789abcdef"));
	else if (c == 'X')
		return (ft_hex(va_arg(arg_list, t_u), "0123456789ABCDEF"));
	else if (c == '%')
		return (ft_putchar('%'));
	return (0);
}

int	ft_printf(const char *string, ...)
{
	va_list	arg_list;
	int		indeks;
	int		len;

	va_start(arg_list, string);
	indeks = 0;
	len = 0;
	while (string[indeks])
	{
		if (string[indeks] == '%')
		{
			len += check(string[indeks + 1], arg_list);
			indeks++;
		}
		else
			len += ft_putchar(string[indeks]);
		indeks++;
	}
	va_end(arg_list);
	return (len);
}
