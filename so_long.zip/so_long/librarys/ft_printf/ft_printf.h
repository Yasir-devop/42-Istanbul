/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: omorkoc <42istanbul.com.tr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/11 11:20:44 by omorkoc           #+#    #+#             */
/*   Updated: 2022/04/12 17:47:52 by omorkoc          ###   ########.tr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H
# include <stdarg.h>
# include <unistd.h>

typedef unsigned int	t_u;
typedef unsigned long	t_l;

int		ft_printf(const char *string, ...);
int		ft_putnbr(int n);
int		ft_putnbr_u(t_u n);
int		ft_putstr(char *s);
int		ft_putchar(char c);
int		ft_hex(t_l value, char *hexadecimal);

#endif