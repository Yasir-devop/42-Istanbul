/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_utils.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: omorkoc <42istanbul.com.tr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/11 11:28:39 by omorkoc           #+#    #+#             */
/*   Updated: 2022/04/12 17:10:20 by omorkoc          ###   ########.tr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_putnbr(int n)
{
	int		len;
	int		temp;
	char	c;

	len = 1;
	if (n == -2147483648)
	{
		len += ft_putstr("-2");
		n = 147483648;
	}
	if (n < 0)
	{
		len += ft_putchar('-');
		n *= -1;
	}
	temp = n;
	c = (temp % 10) + '0';
	if (n >= 10)
		len += ft_putnbr(n / 10);
	ft_putchar(c);
	return (len);
}

int	ft_putnbr_u(t_u n)
{
	char	c;
	int		len;
	t_u		sayi;

	len = 1;
	sayi = n;
	c = (sayi % 10) + '0';
	if (n >= 10)
		len += ft_putnbr_u(n / 10);
	ft_putchar(c);
	return (len);
}

int	ft_putchar(char c)
{
	write(1, &c, 1);
	return (1);
}

int	ft_putstr(char *s)
{
	int	i;

	i = 0;
	if (s)
	{
		while (s[i])
		{
			ft_putchar(s[i]);
			i++;
		}
		return (i);
	}
	else
		write(1, "(null)", 6);
	return (6);
}

int	ft_hex(t_l value, char *hexadecimal)
{
	char	c;
	int		len;
	t_l		temp;

	len = 1;
	temp = value;
	c = hexadecimal[temp % 16];
	if (value >= 16)
		len += ft_hex(value / 16, hexadecimal);
	ft_putchar(c);
	return (len);
}
